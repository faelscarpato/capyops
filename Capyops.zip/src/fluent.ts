import { setTheme } from '@fluentui/web-components';
import { webDarkTheme, webLightTheme } from '@fluentui/tokens';
import '@fluentui/web-components/button.js';
import '@fluentui/web-components/checkbox.js';
import '@fluentui/web-components/dropdown.js';
import '@fluentui/web-components/listbox.js';
import '@fluentui/web-components/message-bar.js';
import '@fluentui/web-components/option.js';
import '@fluentui/web-components/progress-bar.js';
import '@fluentui/web-components/switch.js';
import '@fluentui/web-components/text-input.js';

export function applyFluentTheme(mode: 'light' | 'dark') {
  setTheme(mode === 'dark' ? webDarkTheme : webLightTheme);
}
