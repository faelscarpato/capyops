import { createTheme } from '@mui/material/styles';
import type { PaletteMode } from '@mui/material';

export default function createAppTheme(mode: PaletteMode) {
  const isDark = mode === 'dark';
  const cardBorder = isDark ? '#1F2937' : '#E5E7EB';
  return createTheme({
    palette: {
      mode,
      background: {
        default: isDark ? '#0B0F19' : '#F5F6FA',
        paper: isDark ? '#111827' : '#FFFFFF'
      },
      primary: {
        main: '#2563EB'
      },
      text: {
        primary: isDark ? '#E5E7EB' : '#111827'
      },
      divider: isDark ? '#1F2937' : '#E5E7EB'
    },
    shape: {
      borderRadius: 12
    },
    typography: {
      fontFamily: "'Inter', 'Segoe UI', 'Helvetica Neue', Arial, sans-serif"
    },
    components: {
      MuiCard: {
        styleOverrides: {
          root: {
            border: `1px solid ${cardBorder}`,
            boxShadow: isDark
              ? '0 10px 30px rgba(0, 0, 0, 0.35)'
              : '0 10px 30px rgba(31, 41, 55, 0.08)'
          }
        }
      },
      MuiPaper: {
        styleOverrides: {
          root: {
            border: `1px solid ${cardBorder}`,
            backgroundImage: 'none'
          }
        }
      },
      MuiButton: {
        defaultProps: {
          disableElevation: true
        }
      },
      MuiListItemButton: {
        styleOverrides: {
          root: {
            '&.Mui-selected': {
              boxShadow: isDark ? '0 8px 18px rgba(0,0,0,0.35)' : '0 8px 16px rgba(37,99,235,0.18)'
            }
          }
        }
      }
    }
  });
}
